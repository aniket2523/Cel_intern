import React from 'react';
import FormComponent from './FormComponent';

function App() {
  return (
    <div className="App">
      <h1>Celebal Week One Assignment</h1>
      <FormComponent />
    </div>
  );
}

export default App;
